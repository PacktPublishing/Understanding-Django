from django.shortcuts import render

def index(request):
    if request.user.is_authenticated:
        username = request.user.username
    else:
        username = 'not logged in'

    context = {'username' : username}
    return render(request, 'example/index.html', context)
