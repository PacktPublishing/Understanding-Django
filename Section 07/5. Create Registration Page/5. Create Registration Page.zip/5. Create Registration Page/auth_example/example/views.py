from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm

def index(request):
    if request.user.is_authenticated:
        username = request.user.username
    else:
        username = 'not logged in'

    context = {'username' : username}
    return render(request, 'example/index.html', context)

@login_required
def profile(request):
    return render(request, 'example/profile.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)

        if form.is_valid():
            form.save()
    else:
        form = UserCreationForm()
    
    context = {'form' : form}
    return render(request, 'example/register.html', context)