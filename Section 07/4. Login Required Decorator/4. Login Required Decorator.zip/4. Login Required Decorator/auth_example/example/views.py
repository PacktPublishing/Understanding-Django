from django.shortcuts import render
from django.contrib.auth.decorators import login_required

def index(request):
    if request.user.is_authenticated:
        username = request.user.username
    else:
        username = 'not logged in'

    context = {'username' : username}
    return render(request, 'example/index.html', context)

@login_required
def profile(request):
    return render(request, 'example/profile.html')