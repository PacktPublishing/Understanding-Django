from django.shortcuts import render
from .forms import UsernameForm

def index(request):
    if request.method == 'POST':
        form = UsernameForm(request.POST)

        if form.is_valid():
            print(form.cleaned_data['username'])

    else:
        form = UsernameForm()

    context = {'form' : form}
    
    return render(request, 'example/form.html', context)
