from django import forms 
from django.forms import ModelForm
from django.core.validators import MinLengthValidator
from .models import Car

class UsernameForm(forms.Form):
    username = forms.CharField(max_length=30, validators=[MinLengthValidator(3)], widget=forms.TextInput(attrs={'class' : 'input'}))
    my_bool = forms.BooleanField()
    my_date = forms.DateField()
    my_image = forms.ImageField()
    my_email = forms.EmailField()
    my_choice = forms.ChoiceField(choices=[('1', 'First Choice'), ('2', 'Second Choice'), ('3', 'Third Choice')])

class CarForm(ModelForm):
    class Meta:
        model = Car 
        fields = ['name', 'make', 'year']