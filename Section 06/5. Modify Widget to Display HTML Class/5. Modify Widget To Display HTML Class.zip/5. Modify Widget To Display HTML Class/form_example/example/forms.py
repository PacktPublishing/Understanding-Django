from django import forms 
from django.core.validators import MinLengthValidator

class UsernameForm(forms.Form):
    username = forms.CharField(max_length=30, validators=[MinLengthValidator(3)], widget=forms.TextInput(attrs={'class' : 'input'}))