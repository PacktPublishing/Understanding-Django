from django.contrib import admin
from .models import Simple

admin.site.register(Simple)