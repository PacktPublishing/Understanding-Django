from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseNotFound, Http404

def index(request):
    #raise Http404
    return HttpResponse('<h1>Hello World!</h1>')
    #return HttpResponseNotFound('<h1>Page not found!</h1>')

def register(request):
    #return HttpResponse('<h1>Registration Page</h1>')
    return redirect('timeline')

def profile(request, name='DefaultName'):
    location = request.GET.get('location')
    age = request.GET.get('age')
    return HttpResponse('<h1>Profile Page for {}. The location is {}. Your age is {}.</h1>'.format(name, location, age))

def timeline(request):
    #return HttpResponse('<h1>Timeline Page</h1>')
    return redirect('index')