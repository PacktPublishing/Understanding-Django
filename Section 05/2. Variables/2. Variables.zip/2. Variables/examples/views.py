from django.shortcuts import render

def index(request):
    mydict = {'key1' : 'value1'}
    mylist = [1, 2, 3, 4]
    context = {'name' : 'Pretty Printed', 'mydict' : mydict, 'mylist' : mylist}
    return render(request, 'examples/index.html', context)