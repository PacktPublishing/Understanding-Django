from django.shortcuts import render

def index(request):
    mydict = {'key1' : 'value1'}
    mylist = [1, 2, 3, 4]
    mybool = True
    context = {'name' : 'Pretty Printed', 'mydict' : mydict, 'mylist' : mylist, 'mybool' : mybool}
    return render(request, 'examples/index.html', context)