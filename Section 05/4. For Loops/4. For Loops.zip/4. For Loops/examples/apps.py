from django.apps import AppConfig


class ExamplesConfig(AppConfig):
    name = 'examples'
